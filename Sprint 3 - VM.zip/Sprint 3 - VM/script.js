function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
  }
   
  function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
  }
  
  // Modal Image Gallery
  function onClick(element) {
    document.getElementById("img01").src = element.src;
    document.getElementById("modal01").style.display = "block";
    var captionText = document.getElementById("caption");
    captionText.innerHTML = element.alt;
  }

  //Guardar no localstorage
  
  // Selecionar o formulário
var form = document.querySelector('form');

// Escutar o evento de envio do formulário
form.addEventListener('submit', function(event) {
  event.preventDefault(); // Impedir o envio padrão do formulário

  // Obter os valores dos campos de entrada
  var name = document.querySelector('input[name="Name"]').value;
  var email = document.querySelector('input[name="Email"]').value;
  var message = document.querySelector('input[name="Message"]').value;

    // Verificar se os campos estão preenchidos
    if (name && email && message) {
    // Criar um objeto com os dados do formulário
    var formData = {
      name: name,
      email: email,
      message: message
    };

    // Converter o objeto em uma string JSON
    var formDataJSON = JSON.stringify(formData);

    // Armazenar os dados no LocalStorage
    localStorage.setItem('formData', formDataJSON);

    // Limpar os campos de entrada
    form.reset();

    // Exibir uma mensagem de sucesso para o usuário
    alert('Mensagem enviada com sucesso! Entraremos em contato em breve.');

    // Redirecionar para outra página ou fazer qualquer outra ação necessária
  } else {
    alert('Por favor, preencha todos os campos do formulário.');
  }
});
