// MUDAR A COR DO MENO AO CLIQUE//

var menuItem = document.querySelectorAll('.item-menu')

function selectLink() {
  menuItem.forEach((item) =>
    item.classList.remove('ativo')
  )
  this.classList.add('ativo')
}

menuItem.forEach((item) =>
  item.addEventListener('click', selectLink)
)

document.getElementById('btnAbrirFormulario').addEventListener('click', function() {
  var formulario = document.getElementById('formulario');
  formulario.style.display = 'block';
  console.log("Clicado");
});

document.getElementById('roupaForm').addEventListener('submit', function(event) {
  event.preventDefault();

  // Capturar os valores dos campos de entrada
  var imagem = document.getElementById('imagem').files[0];
  var estilo = document.getElementById('estilo').value;
  var peca = document.getElementById('peca').value;
  var ocasiao = document.getElementById('ocasiao').value;

  // Criar objeto com os dados capturados
  var dadosRoupa = {
    imagem: imagem.name,
    estilo: estilo,
    peca: peca,
    ocasiao: ocasiao
  };

  // Converter objeto para JSON
  var jsonRoupa = JSON.stringify(dadosRoupa);

  // Salvar no localStorage
  localStorage.setItem('roupa', jsonRoupa);

  // Exibir mensagem de sucesso
  console.log('Dados da roupa cadastrados com sucesso!');

  // Limpar os campos de entrada
  document.getElementById('roupaForm').reset();
});