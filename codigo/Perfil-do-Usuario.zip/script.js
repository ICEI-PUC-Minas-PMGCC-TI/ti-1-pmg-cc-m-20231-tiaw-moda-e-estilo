function handleFileSelect(event) {
      var file = event.target.files[0];
      var reader = new FileReader();

      reader.onload = function(e) {
        var profileImage = document.getElementById("profile-image");
        profileImage.style.backgroundImage = "url('" + e.target.result + "')";
        saveImage(e.target.result);
      };

      reader.readAsDataURL(file);
    }

    function toggleEditMode(elementId) {
      var contentElement = document.getElementById(elementId + "-content");
      var textareaElement = document.getElementById(elementId + "-textarea");
      var editButton = document.getElementById(elementId + "-edit-button");
      var saveButton = document.getElementById(elementId + "-save-button");

      if (contentElement.style.display === "none") {
        contentElement.style.display = "block";
        textareaElement.style.display = "none";
        editButton.style.display = "block";
        saveButton.style.display = "none";
        editButton.textContent = "Editar";
      } else {
        contentElement.style.display = "none";
        textareaElement.style.display = "block";
        editButton.style.display = "none";
        saveButton.style.display = "block";
      }
    }

    function saveField(elementId) {
      var contentElement = document.getElementById(elementId + "-content");
      var textareaElement = document.getElementById(elementId + "-textarea");
      contentElement.textContent = textareaElement.value;
      toggleEditMode(elementId);

      // Salvar no localStorage
      localStorage.setItem(elementId, textareaElement.value);
    }

    function saveImage(imageData) {
      // Salvar no localStorage
      localStorage.setItem("profileImage", imageData);
    }

    // Carregar dados do localStorage
    window.addEventListener("DOMContentLoaded", function() {
      var nameContent = document.getElementById("name-content");
      var bioContent = document.getElementById("bio-content");
      var profileImage = document.getElementById("profile-image");

      var storedName = localStorage.getItem("name");
      var storedBio = localStorage.getItem("bio");
      var storedImage = localStorage.getItem("profileImage");

      if (storedName) {
        nameContent.textContent = storedName;
      }

      if (storedBio) {
        bioContent.textContent = storedBio;
      }

      if (storedImage) {
        profileImage.style.backgroundImage = "url('" + storedImage + "')";
      }
    });

// Extra

function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
  }
   
  function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
  }