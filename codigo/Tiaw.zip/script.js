function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
  }
   
  function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
  }
  
  // Modal Image Gallery
  function onClick(element) {
    document.getElementById("img01").src = element.src;
    document.getElementById("modal01").style.display = "block";
    var captionText = document.getElementById("caption");
    captionText.innerHTML = element.alt;
  }

  //Guardar no localstorage
  
  // Selecionar o formulário
var form = document.querySelector('form');

// Escutar o evento de envio do formulário
form.addEventListener('submit', function(event) {
  event.preventDefault(); // Impedir o envio padrão do formulário

  // Obter os valores dos campos de entrada
  var name = document.querySelector('input[name="Name"]').value;
  var email = document.querySelector('input[name="Email"]').value;
  var message = document.querySelector('input[name="Message"]').value;

    // Verificar se os campos estão preenchidos
    if (name && email && message) {
    // Criar um objeto com os dados do formulário
    var formData = {
      name: name,
      email: email,
      message: message
    };

    // Converter o objeto em uma string JSON
    var formDataJSON = JSON.stringify(formData);

    // Armazenar os dados no LocalStorage
    localStorage.setItem('formData', formDataJSON);

    // Limpar os campos de entrada
    form.reset();

    // Exibir uma mensagem de sucesso para o usuário
    alert('Mensagem enviada com sucesso! Entraremos em contato em breve.');

    // Redirecionar para outra página ou fazer qualquer outra ação necessária
  } else {
    alert('Por favor, preencha todos os campos do formulário.');
  }
});

// MUDAR A COR DO MENO AO CLIQUE//

var menuItem = document.querySelectorAll('.item-menu')

function selectLink() {
  menuItem.forEach((item) =>
    item.classList.remove('ativo')
  )
  this.classList.add('ativo')
}

menuItem.forEach((item) =>
  item.addEventListener('click', selectLink)
)

document.getElementById('btnAbrirFormulario').addEventListener('click', function() {
  var formulario = document.getElementById('formulario');
  formulario.style.display = 'block';
  console.log("Clicado");
});

document.getElementById('roupaForm').addEventListener('submit', function(event) {
  event.preventDefault();

  // Capturar os valores dos campos de entrada
  var imagem = document.getElementById('imagem').files[0];
  var estilo = document.getElementById('estilo').value;
  var peca = document.getElementById('peca').value;
  var ocasiao = document.getElementById('ocasiao').value;

  // Criar objeto com os dados capturados
  var dadosRoupa = {
    imagem: imagem.name,
    estilo: estilo,
    peca: peca,
    ocasiao: ocasiao
  };

  // Converter objeto para JSON
  var jsonRoupa = JSON.stringify(dadosRoupa);

  // Salvar no localStorage
  localStorage.setItem('roupa', jsonRoupa);

  // Exibir mensagem de sucesso
  console.log('Dados da roupa cadastrados com sucesso!');

  // Limpar os campos de entrada
  document.getElementById('roupaForm').reset();
});

function handleFileSelect(event) {
      var file = event.target.files[0];
      var reader = new FileReader();

      reader.onload = function(e) {
        var profileImage = document.getElementById("profile-image");
        profileImage.style.backgroundImage = "url('" + e.target.result + "')";
        saveImage(e.target.result);
      };

      reader.readAsDataURL(file);
    }

    function toggleEditMode(elementId) {
      var contentElement = document.getElementById(elementId + "-content");
      var textareaElement = document.getElementById(elementId + "-textarea");
      var editButton = document.getElementById(elementId + "-edit-button");
      var saveButton = document.getElementById(elementId + "-save-button");

      if (contentElement.style.display === "none") {
        contentElement.style.display = "block";
        textareaElement.style.display = "none";
        editButton.style.display = "block";
        saveButton.style.display = "none";
        editButton.textContent = "Editar";
      } else {
        contentElement.style.display = "none";
        textareaElement.style.display = "block";
        editButton.style.display = "none";
        saveButton.style.display = "block";
      }
    }

    function saveField(elementId) {
      var contentElement = document.getElementById(elementId + "-content");
      var textareaElement = document.getElementById(elementId + "-textarea");
      contentElement.textContent = textareaElement.value;
      toggleEditMode(elementId);

      // Salvar no localStorage
      localStorage.setItem(elementId, textareaElement.value);
    }

    function saveImage(imageData) {
      // Salvar no localStorage
      localStorage.setItem("profileImage", imageData);
    }

    // Carregar dados do localStorage
    window.addEventListener("DOMContentLoaded", function() {
      var nameContent = document.getElementById("name-content");
      var bioContent = document.getElementById("bio-content");
      var profileImage = document.getElementById("profile-image");

      var storedName = localStorage.getItem("name");
      var storedBio = localStorage.getItem("bio");
      var storedImage = localStorage.getItem("profileImage");

      if (storedName) {
        nameContent.textContent = storedName;
      }

      if (storedBio) {
        bioContent.textContent = storedBio;
      }

      if (storedImage) {
        profileImage.style.backgroundImage = "url('" + storedImage + "')";
      }
    });

// Extra

function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
  }
   
  function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
  }